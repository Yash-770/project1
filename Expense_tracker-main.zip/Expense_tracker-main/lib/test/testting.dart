enum Category { food, travel, study, leisure, luxury }

void main() {
  print(Category.values);
}
